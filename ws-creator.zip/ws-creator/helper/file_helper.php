<?php
function check_no_repeat_file_name($_name, $_file)
{
  $plugin_name = plugin_name_list();
  $plugin_list_file = scandir(wsp_p_root());
}

function create_dir_name($_name, $_replace = '')
{
  return str_replace(' ', $_replace, $_name);
}

function create_breadcrum_array($_path,$ws_root)
{
    if ( !is_dir($_path) ) {
        print_r("no dir");
        if (!file_exists($_path)) {
            print_r("no file");
            return false;
        }
    }
    $ws_root_path = $ws_root;
    $relative_path = substr($_path, strlen($ws_root_path));
    return explode(DIRECTORY_SEPARATOR, $relative_path);
}

