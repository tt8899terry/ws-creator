<?php


function get_actual_link(){
    return  $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
function http_is_post()
{
    if ($_SERVER['REQUEST_METHOD'] != 'POST') {
        return false;
    }
    return true;
}
function http_is_get()
{
    if ($_SERVER['REQUEST_METHOD'] != 'GET') {
        return false;
    }
    return true;
}
