<?php
function js_fail_msg($arrs = [])
{
    if (!is_array($arrs)) {
?>

        <script>
            _ws_creator_fail_msg.push("<?php echo $arrs; ?>");
        </script>
    <?php

    return true;
    }
    $_msg = '';
    foreach ($arrs as $arr) {
        $_msg = $_msg . $arr;
    }
    ?>

    <script>
        _ws_creator_fail_msg.push("<?php echo $_msg;  ?>");
    </script>
    <?php
}


function js_success_msg($arrs = [])
{
    if (!is_array($arrs)) {
    ?>

        <script>
            _ws_creator_success_msg.push("<?php echo $arrs; ?>");
        </script>
    <?php
    return true;
    }
    $_msg = '';
    foreach ($arrs as $arr) {
        $_msg = $_msg . $arr;
    }
    ?>

    <script>
        _ws_creator_success_msg.push("<?php echo $_msg; ?>");
    </script>
<?php
}
