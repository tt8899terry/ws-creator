<?php

function field_text_helper($f_name, $_label, $_hint = null)
{
?>
    <tr>
        <th scope="row"><label for="<?php echo $f_name; ?>"><?php echo $_label ?></label></th>
        <td>
            <input id="<?php echo $f_name; ?>" type="text" name="<?php echo $f_name; ?>" value="">
            <p class="description" id="tagline-description">
                <?php if ($_hint != null) echo $_hint; ?>
                <b id="<?php echo $f_name; ?>_error_msg" style="color:red;"></b>
                <b id="<?php echo $f_name; ?>_msg"></b>
            </p>
        </td>

    </tr>
<?php
} ?>

<?php

function field_select_helper($f_name, $_label, $_hint = null, $_options=[])
{
?>
    <tr>
        <th scope="row"><label for="<?php echo $f_name; ?>"><?php echo $_label ?></label></th>
        <td>
            <select id="<?php echo $f_name; ?>" name="<?php echo $f_name; ?>">
               <?php
                 foreach($_options as $option){
                     echo '<option value="'.$option.'">'.ucfirst($option).'</option>';
                 }
               ?>
            </select>
            <p class="description" id="tagline-description">
                <?php if ($_hint != null) echo $_hint; ?>
                <b id="<?php echo $f_name; ?>_error_msg" style="color:red;"></b>
                <b id="<?php echo $f_name; ?>_msg"></b>
            </p>
        </td>

    </tr>
<?php
} ?>