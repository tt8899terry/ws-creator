<?php

include 'admin_menu_hook.php';
include plugin_dir_path(__FILE__) . 'view' . DIRECTORY_SEPARATOR . 'view.php';
include plugin_dir_path(__FILE__) . 'submenu_1' . DIRECTORY_SEPARATOR . 'view1.php';
include plugin_dir_path(__FILE__) . 'submenu_1' . DIRECTORY_SEPARATOR . 'submenu1_hook.php';
include plugin_dir_path(__FILE__) . 'submenu_2' . DIRECTORY_SEPARATOR . 'view2.php';
include plugin_dir_path(__FILE__) . 'submenu_2' . DIRECTORY_SEPARATOR . 'submenu2_hook.php';


function wsc_admin_menu_title($space = true)
{
  $name = "WS Creator";
  //return "";
  if ($space == true) return "WS Creator";
  return "ws_creator";
}
function wsc_admin_menu_slug($space = true)
{
  return wsc_admin_menu_title() . "_slug";
}


add_action('admin_menu', 'wporg_options_page');
function wporg_options_page()
{
  $hookname = add_menu_page(
    wsc_admin_menu_title(),
    wsc_admin_menu_title(),
    'manage_options',
    wsc_admin_menu_title(false),
    'wporg_options_page_html',
    // plugin_dir_url(__FILE__) . 'images/icon_wporg.png',
    20
  );
  add_action('load-' . $hookname, 'admin_menu_hook_create_plugin');

  $submenu1 = add_submenu_page(
    wsc_admin_menu_title(false),
    'Edit plugin',
    'Edit plugin',
    'manage_options',
    'ws_edit_plugin',
    'ws_creator_html'
  );

  add_action('load-' . $submenu1, 'submenu1_hook');

  $submenu2 = add_submenu_page(
    wsc_admin_menu_title(false),
    'Edit Theme',
    'Edit Theme',
    'manage_options',
    'ws_edit_theme',
    'ws_creator_theme_html'
  );

  add_action('load-' . $submenu2, 'submenu2_hook');
}
