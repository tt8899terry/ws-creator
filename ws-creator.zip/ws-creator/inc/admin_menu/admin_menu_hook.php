<?php

require_once $ws_creator_root.'/helper/file_helper.php';
function admin_menu_hook_create_plugin()
{

    if (!isset($_REQUEST['_name']) && !isset($_REQUEST['action'])) {
        return false;
    }
    $plugin_name = $_REQUEST['_name'];
    $plugin_type = $_REQUEST['_type'];
    print_r($_REQUEST);
    print_r(create_dir_name($plugin_name));
    $plugin_list_file = scandir(wsp_p_root());
    $folder_name = create_dir_name($plugin_name, '');
    if (in_array($folder_name, $plugin_list_file)) {
        echo "folder cannot create: duplicate";
        return false;
    }
    if (!in_array($plugin_type,['plugin','theme'])) {
        echo "folder cannot create: unknow type";
        return false;
    }
    if($plugin_type=="theme"){
        $re = ws_creator_create_theme($plugin_name,$folder_name);
        return $re; 
    }
    $folder_path = wsp_p_root() . DIRECTORY_SEPARATOR . $folder_name;
    try {
        mkdir($folder_path);
        $myfile = fopen($folder_path . DIRECTORY_SEPARATOR . $folder_name . ".php", "w");
        if (!$myfile) {
            echo 'cannot create file';
            return false;
        }
        $txt = "/**";
        fwrite($myfile, $txt . "\n");
        $txt = " * Plugin Name:       " . $plugin_name;
        fwrite($myfile, $txt . "\n");
        $txt = " */";
        fwrite($myfile, $txt);
        fclose($myfile);
        echo 'plugin created';
        return true;
    } catch (Exception $e) {
        echo $e;

        return false;
    }
}

function ws_creator_create_theme($theme_name,$folder_name){
    try{
        
    }catch(Exception $e){


    }
    echo 'create theme';
    return true;
}
