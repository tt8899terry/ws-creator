<?php
function submenu1_hook()
{



    if (http_is_post()) {
        submenu1_post_action();
    }
}


function submenu1_post_action()
{
    $keys_require = ['_create_type', '_create_name', '_path'];
    foreach ($keys_require as $key_require) {
        if (!array_key_exists($key_require, $_REQUEST)) {

            return false;
        }
    }

    //echo "have hook";
    if ($_REQUEST[$keys_require[0]] == 'dir') {
        ws_submenu_create_dir($_REQUEST);
        return true;
    }
    if ($_REQUEST[$keys_require[0]] == 'file') {
        ws_submenu_create_file($_REQUEST);
        return true;
    }
}
//var _ws_creator_success_msg=[];
//var _ws_creator_fail_msg=[];
function ws_submenu_create_dir($_req)
{
    try {
        $new_dir = stripslashes($_req['_path']) . DIRECTORY_SEPARATOR . $_req['_create_name'];
        $created = @mkdir($new_dir, 777, true);
        if ($created) {
            js_success_msg(['Directory created']);
        } else {
            js_fail_msg(["Dir create fail: check permision or duplicate"]);
        }
    } catch (Exception $e) {

        js_fail_msg(["Dir create fail" . $e]);
    }
}
function ws_submenu_create_file($_req)
{
    try {
        $new_file = stripslashes($_req['_path']) . DIRECTORY_SEPARATOR . $_req['_create_name'];
        if(file_exists($new_file)){
            js_fail_msg('File fail to create:duplicate');
            return false;
        }
        $myfile = fopen($new_file, "w");
        fclose($myfile);
        js_success_msg(['file created']);
    } catch (Exception $e) {

        js_fail_msg("File create fail" . $e);
    }
}
