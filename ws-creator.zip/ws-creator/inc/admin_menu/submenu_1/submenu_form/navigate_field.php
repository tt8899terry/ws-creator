
    <input name="_path" type="hidden" value="<?php echo $path_current; ?>">

    <table class="form-table" role="presentation">
        <tbody>
            <?php field_select_helper('_create_type', "Type", "Create Directory/File", ['dir', 'file']); ?>
            <?php field_text_helper('_create_name', "Name", "Create Directory/File name",); ?>
        </tbody>
    </table>
