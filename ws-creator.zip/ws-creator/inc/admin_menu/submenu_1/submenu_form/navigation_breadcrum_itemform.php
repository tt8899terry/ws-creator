
 <li style="display:inline;">
 <?php echo htmlspecialchars('> ');?>
   <!-- <h3 style="display:inline;"> <?php echo $path_item; ?> </h3> -->
    <form action="" method="POST" style="display:inline">
            <input name="<?php echo $path_key; ?>" type="hidden" value="<?php echo $stack_path; ?>">
            <input type="submit" class="btn-blank" style="display:inline;font-size:x-large;" 
            value="<?php echo $path_item; ?>" <?php if($stack_path==$path_current) echo "disabled"; ?>>
        </form>
</li>