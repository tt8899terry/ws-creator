<ul style="list_style:none;">
    <li style="display:inline;">
        <form action="" method="POST"  style="display:inline">
            <input type="hidden" value="<?php echo $stack_path; ?>">
            <input type="submit" class="btn-blank" style="display:inline;font-size:x-large;" value="Plugin">
        </form>
    </li>
    <?php
    if (is_array($path_array)) {
        foreach ($path_array as $path_item) {
            if (strlen($path_item) > 0) {
                $stack_path = $stack_path . DIRECTORY_SEPARATOR . $path_item;
                include plugin_dir_path(__FILE__) . 'navigation_breadcrum_itemform.php';
            }
        }
    }
    ?>

</ul>
<style>
    .btn-blank {
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
    }
</style>