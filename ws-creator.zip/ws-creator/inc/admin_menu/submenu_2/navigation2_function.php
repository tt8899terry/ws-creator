<?php

function navigation2_function($path_current,$path_key)
{
  
    $stack_path = wsp_theme_root();
    $path_array = create_breadcrum_array($path_current,$stack_path);
    $inner_paths = [];
    
    if ($path_array != false) {
        $inner_paths = scandir($path_current);
        // print_r($inner_paths);
    }
    else{
        print_r("path array is false");
    }

   
    
    include plugin_dir_path( __FILE__ ).'submenu_form'. DIRECTORY_SEPARATOR .'navigation_breadcrum_itemform_home.php';
    
    //print_r($stack_path);
    echo "<br/>";
    foreach ($inner_paths as $inner_path) {
        if ($inner_path == '.' || $inner_path == '..') continue;
        // $_url = 'wp-admin/admin.php?page=ws_edit_plugin';
        $next_path = $path_current . DIRECTORY_SEPARATOR . $inner_path;
?>
        <form action="" method="POST" style="display:inline;">
            <input name="<?php echo $path_key; ?>" type="hidden" value="<?php echo htmlentities($next_path); ?>" />
            <input style="margin:5px;" type="submit" value="<?php echo $inner_path; ?>" <?php if (!is_dir($next_path)) echo "disabled"; ?> />
        </form>

<?php
    }
}
?>
