<?php
function submenu2_hook()
{
    submenu1_hook();
}
