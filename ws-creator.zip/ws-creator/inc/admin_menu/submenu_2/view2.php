<?php

require_once WS_CREATOR_ROOT . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'viewformhelper.php';
function ws_creator_theme_html()
{
    $path_key = "_path";
    if (http_is_post() && isset($_REQUEST[$path_key])) {
        $path_current =   stripslashes($_REQUEST[$path_key]);
    } else {
        $path_current = wsp_theme_root();
    }
?>
    <div class="wrap">
        <h1><?php echo 'Edit Theme'; ?></h1>

        <?php include 'navigation2_function.php';
        navigation2_function($path_current, $path_key); ?>
        <form id="create_theme_form" action="" method="post">
            <?php

            settings_fields(wsc_admin_menu_title(false) . '_options1');
           
            do_settings_sections(wsc_admin_menu_title(false) . '1');
            include  plugin_dir_path(__FILE__) . 'submenu_form' . DIRECTORY_SEPARATOR . 'navigate_field.php';
            
            submit_button(__('Create', 'textdomain'));
            ?>
        </form>

    </div>
    <script>
        console.log("ws creator sucess msg");
        console.log(_ws_creator_success_msg);
        console.log("ws creator fail msg");
        console.log(_ws_creator_fail_msg);
    </script>

<?php } ?>