<?php
include_once WS_CREATOR_ROOT."helper".DIRECTORY_SEPARATOR.'viewformhelper.php';
?>
<h2>Create Plugin</h2>
<?php
$plugin_list_file = scandir(wsp_p_root());

$json_plugin_list = json_encode($plugin_list_file);
?>
<script>
    //  var plugin_list=<?php echo $json_plugin_list ?>;
    var plugin_name_list = <?php echo plugin_name_list() ?>;
</script>

<table class="form-table" role="presentation">
    <tbody>

        <?php field_select_helper("_type","Create Type",null,["plugin"
        //,"theme"
        ]) ?>
        <?php field_text_helper("_name","Plugin Name"," Create Plugin/Theme Name") ?>
    </tbody>
</table>