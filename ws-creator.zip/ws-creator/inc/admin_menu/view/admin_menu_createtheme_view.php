<?php
include_once WS_ROOT."helper".DIRECTORY_SEPARATOR.'viewformhelper.php';
?>
<h2>Create Plugin</h2>
<?php
$plugin_list_file = scandir(wsp_p_root());

$json_plugin_list = json_encode($plugin_list_file);
?>
<script>
    //  var plugin_list=<?php echo $json_plugin_list ?>;
    var plugin_name_list = <?php echo plugin_name_list() ?>;
</script>

<table class="form-table" role="presentation">
    <tbody>
        <tr>
            <th scope="row"><label for="_name">Plugin name</label></th>
            <td>
                <input id="_name" type="text" name="_name" value="">
                <p class="description" id="tagline-description">
                    In a few words, explain what this site is about.<?php // echo wsp_p_root(); 
                                                                    ?>
                    <b id="_name_error_msg" style="color:red;"></b>
                    <b id="_name_msg"></b>
                </p>
            </td>
            <script>
                document.getElementById('_name').onblur = function(e) {
                    var tr_value = e.target.value.trim().toLowerCase();
                    document.getElementById("_name_msg").innerText = '';
                    document.getElementById("_name_error_msg").innerText = '';
                    if (tr_value.length < 3) {
                        document.getElementById("_name_error_msg").innerText = "Plugin name must be at least 3 charactor";
                        return true;
                    }
                    var plugins_lower = plugin_name_list.map(function(v){ return v.toLowerCase()});
                    if (plugins_lower.indexOf(tr_value) >= 0) {
                        document.getElementById("_name_error_msg").innerText = "Plugin name already existed";
                        return true;
                    }
                    document.getElementById("_name_msg").innerText = "you are free to use this name";
                };
            </script>
        </tr>

    </tbody>
</table>