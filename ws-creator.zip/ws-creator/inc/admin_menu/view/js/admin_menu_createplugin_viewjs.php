<script>
    document.getElementById('_name').onblur = function(e) {
        var tr_value = e.target.value.trim().toLowerCase();
        document.getElementById("_name_msg").innerText = '';
        document.getElementById("_name_error_msg").innerText = '';
        if (tr_value.length < 3) {
            document.getElementById("_name_error_msg").innerText = "Plugin name must be at least 3 charactor";
            return true;
        }
        var plugins_lower = plugin_name_list.map(function(v) {
            return v.toLowerCase()
        });
        if (plugins_lower.indexOf(tr_value) >= 0) {
            document.getElementById("_name_error_msg").innerText = "Plugin name already existed";
            return true;
        }
        document.getElementById("_name_msg").innerText = "you are free to use this name";
    };
</script>