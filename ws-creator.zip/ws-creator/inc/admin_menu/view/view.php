<?php

function wporg_options_page_html()
{
?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form id="create_plugin_form" action="" method="post">
            <?php
            
            settings_fields(wsc_admin_menu_title(false) . '_options');
           
            do_settings_sections(wsc_admin_menu_title(false));
            include 'admin_menu_createplugin_view.php';
            
          
            submit_button(__('Save Settings', 'textdomain'));
            ?>
        </form>
        <?php
        include_once plugin_dir_path(__FILE__) . 'js' . DIRECTORY_SEPARATOR . 'admin_menu_createplugin_viewjs.php';
        ?>
    
    </div>
<?php
}

?>