=== Plugin Name ===
Contributors: Andrew Tan
Donate link: http://example.com/
Tags: plugin, theme
Requires at least: 5.3
Tested up to: 7.0
Requires PHP: 7.2
Stable tag: 0.0.1
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
 
Plugin for easy theme and plugin creation. Create plugin /theme without FTP