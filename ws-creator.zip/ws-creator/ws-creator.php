<?php

/**
 * Plugin Name:       WS Creator
 * Description:       Help you easy create theme and plugin when there is no cpanel.
 * Author:            Andrew Tan 
 * Plugin URI:        https://tt8899terry.github.io/ws-creator/
 * Version:           0.0.1
 * License:           GPLv3
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.en.html
 */

 $ws_creator_root= plugin_dir_path(__FILE__);
define('WS_CREATOR_ROOT',$ws_creator_root);

?>
    <script>
        var _ws_creator_success_msg=[];
        var _ws_creator_fail_msg=[];

    </script>
<?php

function wsp_theme_root(){
    return  dirname( get_template_directory(),1);
}
function wsp_p_root(){

    return  dirname(__FILE__,2);
}
function wsp_sp($arrs, $filename)
{
    $path = '';
    foreach ($arrs as $arr) {
        $path = $path.$arr . DIRECTORY_SEPARATOR;
    }

    return $path . $filename;
}

function plugin_name_list($return_json=true){
    $__plugins=get_plugins(  );
    $result=[];
    foreach($__plugins as $__plugin){
       array_push( $result, $__plugin["Title"]);
    }
    if($return_json==true) return json_encode($result);
    return $result;
}


//include plugin_dir_path( __FILE__ ).'/inc/admin_menu/admin_menu.php';
include wsp_sp(
    [
        WS_CREATOR_ROOT,
        'helper'
    ],
    'http_helper.php'
);
include wsp_sp(
    [
        WS_CREATOR_ROOT,
        'helper'
    ],
    'jsmsghelper.php'
);
include wsp_sp(
    [
        WS_CREATOR_ROOT,
        'inc', 'admin_menu'
    ],
    'admin_menu.php'
);

